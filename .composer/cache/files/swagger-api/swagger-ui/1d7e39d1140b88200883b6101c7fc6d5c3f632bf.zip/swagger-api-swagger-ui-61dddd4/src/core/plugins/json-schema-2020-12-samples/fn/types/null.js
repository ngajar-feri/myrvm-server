/**
 * @prettier
 */

const nullType = () => {
  return null
}

export default nullType
