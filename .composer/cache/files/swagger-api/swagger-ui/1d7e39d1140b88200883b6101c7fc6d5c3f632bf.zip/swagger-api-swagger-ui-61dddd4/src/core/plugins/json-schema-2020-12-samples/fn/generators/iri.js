/**
 * @prettier
 */
const iriGenerator = () => "https://실례.com/"

export default iriGenerator
